% Startup script for sm_robot_6legs_4bar.slx
% Copyright 2018 The MathWorks, Inc.

addpath([pwd filesep 'Images']);
addpath([pwd filesep 'Libraries']);
addpath([pwd filesep 'Scripts_Data']);
sm_robot_6legs_4bar_param
sm_robot_6legs_4bar
