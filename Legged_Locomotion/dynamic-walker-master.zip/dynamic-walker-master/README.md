# dynamic-walker
This is a project on the simulation of a Passive Dynamic Walker

The basic goal of this project is to simulate a Passive Dynamic Walker in a simulated real world with the help of the Gazebo simulator. Gazebo 6 has been made use of for this purpose. The file that handles the simulation is the PDW_Foot_1 . This is basically a SDF (Simulation Description Format) file. The CAD files attached herewith are linked with the SDF file in order get the model of the Passive Dynamic Walker into the simulated Gazebo world.
