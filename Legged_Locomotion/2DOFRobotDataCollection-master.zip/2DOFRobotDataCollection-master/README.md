# Creating example 2DOF robot trajectories

Created a 2DOF robot with urdf and xacro so that it can be shown in Gazebo.

Created a program so that it can randomly generate sin like velocity patterns by using ros_control.
